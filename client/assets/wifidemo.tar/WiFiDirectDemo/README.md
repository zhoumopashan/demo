WiFiDirectDemo
==============


A android application about Wifi-Direct P2P Share your picture.
Thanks.

Author	- Junkun Huang.
Email	- huangjunkun@gmail.com 
